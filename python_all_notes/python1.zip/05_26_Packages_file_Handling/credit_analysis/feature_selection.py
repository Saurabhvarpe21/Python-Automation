print('Feature Selection File.....')

# from data_preprocessing import label_encoding

def forward_feature_selection():
    print('Forward Feature Selection Method')


# label_encoding()