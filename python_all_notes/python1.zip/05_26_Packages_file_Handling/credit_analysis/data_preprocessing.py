print('Data Pre-Processing File.....')

def label_encoding():
    print('Label Encoding Function')


if __name__ == "__main__":
    label_encoding()