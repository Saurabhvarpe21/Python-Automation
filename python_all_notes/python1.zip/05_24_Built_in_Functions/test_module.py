
import calculation

print(calculation.multiplication(40,10))

print('__name__ is :', __name__)