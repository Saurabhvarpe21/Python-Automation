print('Division File')

def div(a,b):
    d = a/b
    print(f'Division of {a} and {b} == {d} ')
    return d