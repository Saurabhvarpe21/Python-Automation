print('Multiplication File........')

def mul(x, y):
    mul1 = x * y
    print(f'Multiplication of {x} and {y} == {mul1} ')
    return mul1

if __name__ == "__main__":
    mul(5,7)