print('Initialising code...........')

print('Bharat Mata ki Jay')