def new():
    print(f'First Modules name : {__name__}')

new()
if __name__ == '__main__':
    new()