from Velocity.division import div
# import Velocity.add

# from Velocity.multiply import mul


import Module and Packages





print(div(50,4))
print(mul(7,8))