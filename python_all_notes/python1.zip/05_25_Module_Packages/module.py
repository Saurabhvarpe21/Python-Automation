# print('Hello Python')
# print('We are testing main Module')
# print('Value of __name__ is >> ', __name__)  # __main__


var1 = 100
d1 = {'Virat': 'Anushka', 'Dhoni':'Sakshi'}

def addition(a,b):
    c = a+b
    print(f'Addition of {a} and {b} == {c} ')

    return c

if __name__ == '__main__':
    addition(10,30)
    print('Hello Python')
    print('We are testing main Module')
    print('Value of __name__ is >> ', __name__)  # __main__