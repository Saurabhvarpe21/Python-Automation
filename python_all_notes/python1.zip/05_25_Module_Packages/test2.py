import test1
print(f'Second Module name is: {__name__}')