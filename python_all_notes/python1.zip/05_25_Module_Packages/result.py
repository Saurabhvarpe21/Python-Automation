# from Calculations import addition,multiplication
import Calculations as cal

print(cal.addition(14,8))

print(cal.multiplication(5,6))