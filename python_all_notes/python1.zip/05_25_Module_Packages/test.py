import module
import test_module

print(module.addition(20,40))
print(test_module.add(45,8))

print(module.var1)
print(module.d1['Dhoni'])

print('Value of __name__ is >> ', __name__)